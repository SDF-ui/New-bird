package com.example.study;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends Activity {
    private Button btn_send;
    private Button btn_send_1;
    private Button btn_send_2;
    private EditText et_password;
    private EditText et_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et_name = (EditText) findViewById(R.id.editText);
        et_password = (EditText) findViewById(R.id.editText2);
        btn_send = (Button) findViewById(R.id.button);
        btn_send.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                passDate();
            }
        });//这里，规范的问题

    }

    public void passDate() {
        //创建Intent对象,启动
        //核心部分的问题
        Intent intent = new Intent(this, course.class);
        //将数据存入Intent对象
        intent.putExtra("name", et_name.getText().toString().trim());
        intent.putExtra("password", et_password.getText().toString().trim());
        startActivity(intent);
    }
}
