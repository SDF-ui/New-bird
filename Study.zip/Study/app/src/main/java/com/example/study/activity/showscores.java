package com.example.study.activity;

import android.widget.*;
import android.os.Bundle;
import com.example.study.R;
import android.content.Intent;

import android.view.View;
import android.app.Activity;

import com.example.study.visual.ScoreAdapter;
import com.example.study.control.DBController;
import com.example.study.database.Score;

import java.util.ArrayList;

public class showscores extends Activity {

    TextView textView;
    DBController dbController;
    ListView listView;
    String cn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showscores);
        dbController = new DBController(getApplicationContext());

        //获取对应的课程名称
        //然而并未成功
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        cn = bundle.getString("cn");
        StringBuilder text = new StringBuilder();
        text.append(cn).append("成绩单").append(System.getProperty("line.separator"));
        text.append("课程                                 ").append("成绩");

        textView = (TextView) findViewById(R.id.tv);
        //textView.setText(cn+"成绩单");
        textView.setText(text);
        //列表设置
        ArrayList<Score> list = dbController.testQueryDate(cn);
        //查出对应的数据
        listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(new ScoreAdapter(list,getApplication()));

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                //通过 课程名 获取到要删除的是哪门课
                Score score = dbController.testQueryDate(cn).get(i);
                //根据 考试名称 删除对应的数据
                dbController.testDeleteDate(score.EN);
                return false;
            }
        });
    }
}