package com.example.study;

import android.app.ActionBar;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.app.Activity;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class mainpage extends Activity {

    private Button btn_send;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainpage);
        btn_send = (Button) findViewById(R.id.button3);
        btn_send.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                passDate();
            }
        });//这里，规范的问题
    }

    public void passDate() {
        //创建Intent对象,启动
        //核心部分的问题
        Intent intent = new Intent(this, course.class);
        //将数据存入Intent对象
        startActivity(intent);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //打开时显示
        getMenuInflater().inflate(R.menu.main, menu);
        ActionBar actionBar = getActionBar();
        actionBar.setLogo(R.drawable.course);
        actionBar.setDisplayUseLogoEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);

        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_search:
                Toast.makeText(this, "你点击了“Search”按键！", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.action_settings:
                Toast.makeText(this, "你点击了“Setting”按键！", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.action_view:
                Toast.makeText(this, "你点击了“view”按键！", Toast.LENGTH_SHORT).show();
                return true;
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public ActionBar getSupportActionBar() {
        ActionBar supportActionBar = null;
        return supportActionBar;
    }
}