package com.example.study.database;

/**
 * Created by Administrator on 2019/9/21.
 */

public class Score {
    public String CN = null;
    public String EN = null;
    public String SCORE = null;
    public String GRADE = null;
}
