package com.example.study.activity;

import android.app.ActionBar;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.app.Activity;
import android.os.Bundle;
import com.example.study.R;

public class mainpage extends Activity {

    private Button btn_toCourse;
    private Button btn_toGrade;
    private Button btn_toFree;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainpage);
        btn_toCourse = (Button) findViewById(R.id.course);
        btn_toCourse.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                passDate();
            }
        });//这里，规范的问题


        btn_toGrade = (Button) findViewById(R.id.grade);
        btn_toGrade.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                toGrade();
            }
        });//这里，规范的问题

        btn_toFree = (Button) findViewById(R.id.free);
        btn_toFree.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                toFree();
            }
        });//这里，规范的问题
    }

    public void passDate() {
        //创建Intent对象,启动
        //核心部分的问题
        Intent intent = new Intent(this, coursetable.class);
        //将数据存入Intent对象
        startActivity(intent);
    }

    public void toGrade() {
        //创建Intent对象,启动
        //核心部分的问题
        Intent intent = new Intent(this, inputgrade.class);
        //将数据存入Intent对象
        startActivity(intent);
    }

    public void toFree() {
        //创建Intent对象,启动
        //核心部分的问题
        Intent intent = new Intent(this, freetable.class);
        //将数据存入Intent对象
        startActivity(intent);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //打开时显示
        getMenuInflater().inflate(R.menu.main, menu);
        ActionBar actionBar = getActionBar();
        actionBar.setLogo(R.drawable.course);
        actionBar.setDisplayUseLogoEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);

        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_search:
                Toast.makeText(this, "你点击了“Search”按键！", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.action_settings:
                Toast.makeText(this, "你点击了“Setting”按键！", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.action_view:
                Toast.makeText(this, "你点击了“view”按键！", Toast.LENGTH_SHORT).show();
                return true;
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public ActionBar getSupportActionBar() {
        ActionBar supportActionBar = null;
        return supportActionBar;
    }
}